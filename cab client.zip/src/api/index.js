import API from "./API";
import endpoints from "./endpoints.json";

export { API, endpoints };
