import * as React from "react";

interface IBookingProps {}

const Booking: React.FunctionComponent<IBookingProps> = (props) => {
  return (
    <>
      <h1>Booking module</h1>
    </>
  );
};

export default Booking;
