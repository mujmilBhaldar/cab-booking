import * as React from "react";

interface ICustomerProps {}

const Customer: React.FunctionComponent<ICustomerProps> = (props) => {
  return (
    <>
      <h1>Customer module</h1>
    </>
  );
};

export default Customer;
