import * as React from "react";

interface IUserProps {}

const User: React.FunctionComponent<IUserProps> = (props) => {
  return (
    <>
      <h1>User module</h1>
    </>
  );
};

export default User;
