import * as React from "react";

interface IAboutProps {}

const About: React.FunctionComponent<IAboutProps> = (props) => {
  return (
    <>
      <h2>About component</h2>
    </>
  );
};

export default About;
