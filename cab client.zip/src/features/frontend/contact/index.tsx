import * as React from "react";

interface IContactProps {}

const Contact: React.FunctionComponent<IContactProps> = (props) => {
  return (
    <>
      <h2>Contact component</h2>
    </>
  );
};

export default Contact;
