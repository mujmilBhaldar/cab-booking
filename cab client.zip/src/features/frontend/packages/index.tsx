import * as React from "react";

interface IPackagesProps {}

const Packages: React.FunctionComponent<IPackagesProps> = (props) => {
  return (
    <>
      <h2>Packages Component</h2>
    </>
  );
};

export default Packages;
