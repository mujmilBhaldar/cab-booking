import * as React from "react";

interface ITarrifProps {}

const Tarrif: React.FunctionComponent<ITarrifProps> = (props) => {
  return (
    <>
      <h2>Tarrif</h2>
    </>
  );
};

export default Tarrif;
