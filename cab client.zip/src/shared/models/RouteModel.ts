interface RouteModel {
  path: string;
  component?: any;
  showInMenu?: boolean;
  label?: string;
  role?: string;
  icon?: any;
}

export default RouteModel;
